A Tower-House Design by DennisH2010.

Animated Yes
Rigged Yes
Lowpoly (game-ready) Yes
Geometry Polygon mesh
Polygons 3,634
Vertices 5,654
Textures Yes
Materials Yes
UV Mapping Yes
Unwrapped UVs Non-overlapping

Demo Video: https://www.youtube.com/watch?v=pwUi4D7aUTM
3d-Preview on Sketchfab : https://sketchfab.com/models/a972a15421a942429f1279824e00c042

Homepage: http://3dartdh.wordpress.com/
Contact me: https://3dartdh.wordpress.com/contact/
Sketchfab: https://sketchfab.com/dennish2010
YouTube: https://www.youtube.com/user/DennisH2010

